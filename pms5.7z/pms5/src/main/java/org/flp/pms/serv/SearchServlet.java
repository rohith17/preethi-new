package org.flp.pms.serv;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.domain.Product;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;
import com.google.gson.Gson;

/**
 * Servlet implementation class SearchServlet
 */
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
   
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		Gson myjson=new Gson();
		IProductService iProductService=new ProductServiceImpl();
		String searchBy=request.getParameter("searchBy");
		String SearchData=request.getParameter("searchvalue");
		System.out.println(searchBy);
		System.out.println(SearchData);
		//if(action.equalsIgnoreCase("Name")){
				if(searchBy.equalsIgnoreCase("Name")){
					Product product=iProductService.search_By_Name(SearchData);
					response.setContentType("application/json");
					String namejson=myjson.toJson(product);
					System.out.println(namejson);
					
					iProductService.storeJsonData(namejson);
					response.sendRedirect("pages/DisplaySearch.html");
				}
		
}
}