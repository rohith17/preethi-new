package org.flp.pms.serv;


import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.dao.IProductDao;
import com.flp.pms.dao.ProductDaoImplForMap;
import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;



public class addProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter writer=response.getWriter();
		IProductDao pdao=new ProductDaoImplForMap();
		Category category=new Category();
		SubCategory subcategory= new SubCategory();
		Supplier supplier=new Supplier();
		Discount discount=new Discount();
		SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-DD");
		String productName=request.getParameter("pname");
		String description=request.getParameter("pdesc");
		String manufacturing_date=request.getParameter("manuDate");
		String expiry_date=request.getParameter("exDate");
		String max_retail_price=request.getParameter("mrp");
		String catName=request.getParameter("catName");
		String subName=request.getParameter("subcatName");
		String supplierName=request.getParameter("supplier");
		String[] discountName=request.getParameterValues("discount");
		String quantity=request.getParameter("quant");
	    String ratings=request.getParameter("rate");
	    
	    System.out.println(catName);
	    System.out.println(subName);
	    System.out.println(supplierName);
		
		Product product=new Product();
		product.setProductName(productName);
		product.setDescription(description);
		product.setMax_retail_price(Double.parseDouble(max_retail_price));
		
		try {
			product.setManufacturing_date(format.parse(manufacturing_date));
			product.setExpiry_date(format.parse(expiry_date));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		List<Category> categories=pdao.getAllCategory();
		for(Category c:categories)
		{
			if(c.getCategory_Id()==Integer.parseInt(catName));
				category=c;
		}
		
		
		product.setCategory(category);
		List<SubCategory> subcategories=pdao.getAllSubCategory();
		for(SubCategory sub:subcategories)
		{
			if(sub.getSub_category_Id()==Integer.parseInt(subName))
				subcategory=sub;
		} 
		
		product.setSubCategory(subcategory);
	   List<Supplier> suppliers=pdao.getAllSuppliers();
	
		for(Supplier supl:suppliers)
		{
			if(supl.getSupplierId()==Integer.parseInt(supplierName))
				supplier=supl;
				
		}
		product.setSupplier(supplier);
		
		List<Discount> discounts=pdao.getAllDiscounts();
		List<Discount> discounts2=new ArrayList<Discount>();
		int len=discountName.length;
		int i=0;
		for(Discount dis:discounts)
		{
			if(i<len){
			if(dis.getDiscountName().equalsIgnoreCase(discountName[i]));
				discounts2.add(dis);
				i++;
			}	
		}
		
		
	
		product.setDiscounts(discounts2);
		product.setQuantity(Integer.parseInt(quantity));
		product.setRatings(Float.parseFloat(ratings));
		
		
		System.out.println(product);
		IProductService iProductService = new ProductServiceImpl();
		
		iProductService.addProduct(product);
		
		
		response.sendRedirect("pages/success.html");
		
		System.out.println(product);
		
		
	
		
	}

}
