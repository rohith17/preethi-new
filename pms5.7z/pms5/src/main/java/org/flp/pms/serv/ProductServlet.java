package org.flp.pms.serv;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.dao.IProductDao;
import com.flp.pms.dao.ProductDaoImplForMap;
import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;
import com.google.gson.Gson;

public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("application/json");
		IProductDao pdao=new ProductDaoImplForMap();
		Gson myJson=new Gson();
		
		String action=request.getParameter("action");
		
		if(action.equalsIgnoreCase("category")){
			response.setContentType("application/json");
		List<Category> categories=pdao.getAllCategory();
	     String categoryJson=myJson.toJson(categories);
	    out.println(categoryJson);
		}
		
		
		if(action.equalsIgnoreCase("subCategory")){
			response.setContentType("application/json");
			List<SubCategory> subcategories=pdao.getAllSubCategory();
		     String subcategoryJson=myJson.toJson(subcategories);
		    out.println(subcategoryJson);
			}
	
		if(action.equalsIgnoreCase("supplier")){
			response.setContentType("application/json");
			List<Supplier> suppliers=pdao.getAllSuppliers();
		     String supplierJson=myJson.toJson(suppliers);
		    out.println(supplierJson);
			}

		if(action.equalsIgnoreCase("discount")){
			response.setContentType("application/json");
			List<Discount> discounts=pdao.getAllDiscounts();
		     String discountJson=myJson.toJson(discounts);
		    out.println(discountJson);
			}	

		if(action.equalsIgnoreCase("product")){
			response.setContentType("application/json");
			List<Product> products=pdao.getAllProducts1();
		     String productJson=myJson.toJson(products);
		    out.println(productJson);
			}	
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doGet(request, response);
	}

}
